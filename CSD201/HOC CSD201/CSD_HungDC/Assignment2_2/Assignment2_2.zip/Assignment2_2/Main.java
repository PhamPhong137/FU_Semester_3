/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2_2;

/**
 *
 * @author dmngh
 */
public class Main {
    public static void main(String[] args) {
        MyTree my = new MyTree();
        
//        // f1
//        my.f1(my);
        
//        //f2
//        my.f2(my);

//        //f3
//        my.f3(my);

//        //f4
//        my.f4(my);
    }
}
